var structrectangle =
[
    [ "bottom_right", "structrectangle.html#a6920a2662992d3f86825dbcbe8264659", null ],
    [ "top_left", "structrectangle.html#a728703fcf5a71a4e1b156cfc6f4504e0", null ]
];