var classmatrix =
[
    [ "matrix", "classmatrix.html#a2994d419451e97702e5b1cc12c81d914", null ],
    [ "matrix", "classmatrix.html#a4daf70b1506ea976352f20e4322a9c17", null ],
    [ "add_val", "classmatrix.html#ae9817c7c1a8855874728c2342f514885", null ],
    [ "get_cols", "classmatrix.html#ae8479003bb1373c0f27f7f59980d5e3a", null ],
    [ "get_rows", "classmatrix.html#a528d089b9734f7cda64ffab3a2d2831f", null ],
    [ "get_val", "classmatrix.html#a4913d355d918c769b200cc0b6bffbd68", null ],
    [ "multiply", "classmatrix.html#a34563095940d2be0e50d98fbb2ba9ead", null ],
    [ "print", "classmatrix.html#a820379d929b5a1c49c9df0d05f91c7e2", null ],
    [ "set_col", "classmatrix.html#a976c7dba1c9f40d6c129067fd4c5afc1", null ],
    [ "set_row", "classmatrix.html#a2e865089f895c8a84c37818cf75ca215", null ],
    [ "set_up_transformation", "classmatrix.html#a159c12c74a7a58596e297a29094eb1f9", null ],
    [ "set_val", "classmatrix.html#a761067e4f67f5b9c23594cbc1d8ce696", null ]
];