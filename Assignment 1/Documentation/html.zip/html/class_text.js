var class_text =
[
    [ "Text", "class_text.html#a98ff94dc4040712884de7d62c04967d1", null ],
    [ "draw", "class_text.html#adedc069a9ad622bf9d2cf6d194a01b39", null ],
    [ "update_text", "class_text.html#ae3fc12110b4324c661aa3d279d71159c", null ]
];