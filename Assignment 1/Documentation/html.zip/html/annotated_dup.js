var annotated_dup =
[
    [ "colour", "structcolour.html", "structcolour" ],
    [ "matrix", "classmatrix.html", "classmatrix" ],
    [ "point", "structpoint.html", "structpoint" ],
    [ "Polygon", "class_polygon.html", "class_polygon" ],
    [ "rectangle", "structrectangle.html", "structrectangle" ],
    [ "Text", "class_text.html", "class_text" ],
    [ "velocity", "structvelocity.html", "structvelocity" ]
];