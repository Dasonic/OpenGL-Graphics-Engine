var searchData=
[
  ['undo_5ftransformation',['undo_transformation',['../class_polygon.html#a9c058c0a82c8d8138301d2c6ec049d09',1,'Polygon']]],
  ['update_5ftext',['update_text',['../class_text.html#ae3fc12110b4324c661aa3d279d71159c',1,'Text']]]
];
