var searchData=
[
  ['draw',['draw',['../class_polygon.html#a17428a7d7dff4653c905b91020a9f803',1,'Polygon::draw()'],['../class_text.html#adedc069a9ad622bf9d2cf6d194a01b39',1,'Text::draw()']]]
];
