var searchData=
[
  ['save_5ftransformation',['save_transformation',['../class_polygon.html#aca723d97ae607e5079cd5dfd7ba616d3',1,'Polygon']]],
  ['scale',['scale',['../class_polygon.html#a3166ec344b0453bde49f6c32300eab12',1,'Polygon']]],
  ['set_5fcol',['set_col',['../classmatrix.html#a976c7dba1c9f40d6c129067fd4c5afc1',1,'matrix']]],
  ['set_5fcolour',['set_colour',['../class_polygon.html#a5895893a117ad4fba5422e9269ff729c',1,'Polygon']]],
  ['set_5frow',['set_row',['../classmatrix.html#a2e865089f895c8a84c37818cf75ca215',1,'matrix']]],
  ['set_5fup_5ftransformation',['set_up_transformation',['../classmatrix.html#a159c12c74a7a58596e297a29094eb1f9',1,'matrix']]],
  ['set_5fval',['set_val',['../classmatrix.html#a761067e4f67f5b9c23594cbc1d8ce696',1,'matrix']]]
];
