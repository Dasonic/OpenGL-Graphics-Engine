var searchData=
[
  ['add_5fval',['add_val',['../classmatrix.html#ae9817c7c1a8855874728c2342f514885',1,'matrix']]],
  ['additive_5frotate',['additive_rotate',['../class_polygon.html#aa058b0c05dcb8a9c4c0f2737ac59fb64',1,'Polygon']]],
  ['additive_5ftranslate',['additive_translate',['../class_polygon.html#aa066ce6c55fe73f2187919085016e9ec',1,'Polygon']]]
];
