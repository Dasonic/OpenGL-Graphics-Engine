var searchData=
[
  ['get_5fcols',['get_cols',['../classmatrix.html#ae8479003bb1373c0f27f7f59980d5e3a',1,'matrix']]],
  ['get_5frows',['get_rows',['../classmatrix.html#a528d089b9734f7cda64ffab3a2d2831f',1,'matrix']]],
  ['get_5fval',['get_val',['../classmatrix.html#a4913d355d918c769b200cc0b6bffbd68',1,'matrix']]]
];
