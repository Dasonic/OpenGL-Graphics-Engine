var searchData=
[
  ['matrix',['matrix',['../classmatrix.html#a2994d419451e97702e5b1cc12c81d914',1,'matrix::matrix(int num_rows, int num_cols)'],['../classmatrix.html#a4daf70b1506ea976352f20e4322a9c17',1,'matrix::matrix()']]],
  ['multiply',['multiply',['../classmatrix.html#a34563095940d2be0e50d98fbb2ba9ead',1,'matrix']]]
];
