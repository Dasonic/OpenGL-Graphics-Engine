var searchData=
[
  ['polygon',['Polygon',['../class_polygon.html#a7c9801ab8183848cda1a9e4e355973cc',1,'Polygon::Polygon(std::vector&lt; point &gt; points, point coordinates)'],['../class_polygon.html#a84c5ba9b7d4fbbfd85e2485712d282d8',1,'Polygon::Polygon(std::vector&lt; point &gt; points)'],['../class_polygon.html#ac183e712f8be1e13f1c9d5b4d4512ead',1,'Polygon::Polygon()']]],
  ['print',['print',['../classmatrix.html#a820379d929b5a1c49c9df0d05f91c7e2',1,'matrix']]]
];
