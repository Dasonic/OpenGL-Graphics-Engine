var searchData=
[
  ['change_5fpoints',['change_points',['../class_polygon.html#ab5a643b45071142291a93070f36e9159',1,'Polygon']]]
];
