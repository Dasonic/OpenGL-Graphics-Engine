var searchData=
[
  ['find_5fbottom_5fright_5fpoint',['find_bottom_right_point',['../class_polygon.html#a1f9b4d001197e6ff84fb4ed50b47be59',1,'Polygon']]],
  ['find_5ftop_5fleft_5fpoint',['find_top_left_point',['../class_polygon.html#a1c99b0b80833ef2eca19b98530d90910',1,'Polygon']]]
];
