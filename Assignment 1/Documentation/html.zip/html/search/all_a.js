var searchData=
[
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#a98ff94dc4040712884de7d62c04967d1',1,'Text::Text()']]],
  ['translate',['translate',['../class_polygon.html#a8981ae2ebe960a7355134f03dc88f1e3',1,'Polygon']]]
];
