var structcolour =
[
    [ "B", "structcolour.html#ab8699c79e9d979c413799dcf47e606d2", null ],
    [ "G", "structcolour.html#ae459b0b040ebe7eb15e77b26760ac53a", null ],
    [ "R", "structcolour.html#af66bc24a6bed26fe8d97cb512caa97de", null ]
];