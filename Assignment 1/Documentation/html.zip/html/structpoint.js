var structpoint =
[
    [ "x", "structpoint.html#ad679b07fb69d55f5ad454d0f1f2891d5", null ],
    [ "y", "structpoint.html#a9a82ca9504acabb1e30569f89c805471", null ]
];